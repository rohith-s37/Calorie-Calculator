export interface BuiltinActivity {
  name: string;
  calPerKm: number;
}

export const BUILTIN_ACTIVITIES: BuiltinActivity[] = [
  { name: "Walking", calPerKm: 55 },
  { name: "Jogging", calPerKm: 62 },
  { name: "Cycling", calPerKm: 26 },
  { name: "Running", calPerKm: 70 },
  { name: "Swimming", calPerKm: 55 },
  { name: "Gym - Cardio", calPerKm: 90 },
  { name: "Gym - Weights", calPerKm: 60 },
  { name: "Yoga", calPerKm: 20 },
  { name: "Stretching", calPerKm: 10 },
  { name: "Dancing", calPerKm: 40 },
  { name: "Badminton", calPerKm: 45 },
  { name: "Cricket", calPerKm: 35 },
  { name: "Football", calPerKm: 50 },
  { name: "Basketball", calPerKm: 55 },
  { name: "Tennis", calPerKm: 48 },
  { name: "Volleyball", calPerKm: 30 },
  { name: "Hockey", calPerKm: 52 },
  { name: "Boxing", calPerKm: 80 },
  { name: "Skipping", calPerKm: 75 },
  { name: "Hiking", calPerKm: 60 },
];
