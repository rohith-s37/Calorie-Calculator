import type { AppState, FoodEntry, ActivityEntry, CustomFood, CustomActivity } from "../types";

const KEY = "health-tracker-data";

const DEFAULT_CUSTOM_FOODS: CustomFood[] = [
  { id: "bf1", name: "Dosa", calories: 150, protein: 4, fiber: 1 },
  { id: "bf2", name: "Idly", calories: 40, protein: 1, fiber: 0 },
  { id: "bf3", name: "Sambar", calories: 50, protein: 3, fiber: 2 },
  { id: "bf4", name: "Rice", calories: 130, protein: 2.7, fiber: 0.4 },
  { id: "bf5", name: "Roti", calories: 70, protein: 3, fiber: 1.2 },
  { id: "bf6", name: "Dal", calories: 80, protein: 6, fiber: 3 },
  { id: "bf7", name: "Chicken Curry", calories: 120, protein: 18, fiber: 0 },
  { id: "bf8", name: "Egg", calories: 70, protein: 6, fiber: 0 },
];

const DEFAULT_SETTINGS = {
  calorieTarget: 1550,
  proteinGoal: 70,
  fiberGoal: 25,
};

const DEFAULT_STATE: AppState = {
  foodLog: [],
  activityLog: [],
  customFoods: DEFAULT_CUSTOM_FOODS,
  customActivities: [],
  hiddenBuiltins: [],
  settings: DEFAULT_SETTINGS,
};

export function loadState(): AppState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULT_STATE, customFoods: [...DEFAULT_CUSTOM_FOODS] };
    const parsed = JSON.parse(raw) as AppState;
    return {
      foodLog: parsed.foodLog ?? [],
      activityLog: parsed.activityLog ?? [],
      customFoods: parsed.customFoods ?? [...DEFAULT_CUSTOM_FOODS],
      customActivities: parsed.customActivities ?? [],
      hiddenBuiltins: parsed.hiddenBuiltins ?? [],
      settings: parsed.settings ?? { ...DEFAULT_SETTINGS },
    };
  } catch {
    return { ...DEFAULT_STATE, customFoods: [...DEFAULT_CUSTOM_FOODS] };
  }
}

export function saveState(state: AppState) {
  localStorage.setItem(KEY, JSON.stringify(state));
}

export function formatDate(d: Date): string {
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yyyy = d.getFullYear();
  return `${dd}-${mm}-${yyyy}`;
}

export function todayStr(): string {
  return formatDate(new Date());
}

export function exportData(state: AppState) {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `health-tracker-export-${todayStr()}.json`;
  a.click();
  URL.revokeObjectURL(url);
}
