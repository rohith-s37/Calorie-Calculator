import { useState } from "react";
import type { AppState, ActivityEntry, CustomActivity } from "../types";
import { todayStr, formatDate } from "../lib/storage";
import { BUILTIN_ACTIVITIES } from "../lib/builtinActivities";

interface Props {
  state: AppState;
  setState: (s: AppState) => void;
}

function toInputDate(ddmmyyyy: string): string {
  const [dd, mm, yyyy] = ddmmyyyy.split("-");
  return `${yyyy}-${mm}-${dd}`;
}

function fromInputDate(yyyymmdd: string): string {
  const [yyyy, mm, dd] = yyyymmdd.split("-");
  return `${dd}-${mm}-${yyyy}`;
}

export default function ActivityTab({ state, setState }: Props) {
  const [actName, setActName] = useState("");
  const [kms, setKms] = useState("");
  const [logDate, setLogDate] = useState(toInputDate(todayStr()));
  const [customName, setCustomName] = useState("");
  const [customCal, setCustomCal] = useState("");

  const today = todayStr();
  const selectedDate = fromInputDate(logDate);
  const todayActivities = state.activityLog.filter((e) => e.date === selectedDate);

  const hiddenBuiltins = state.hiddenBuiltins ?? [];
  const visibleBuiltins = BUILTIN_ACTIVITIES.filter(
    (a) => !hiddenBuiltins.includes(a.name)
  );

  const allActivities = [...visibleBuiltins, ...state.customActivities];

  function getCalPerKm(name: string): number {
    const full = [...BUILTIN_ACTIVITIES, ...state.customActivities];
    const match = full.find((a) => a.name.toLowerCase() === name.toLowerCase());
    return match ? match.calPerKm : 50;
  }

  function addActivity() {
    const km = parseFloat(kms);
    if (!actName.trim() || isNaN(km) || km <= 0) return;
    const calPerKm = getCalPerKm(actName.trim());
    const burned = Math.round(calPerKm * km);
    const entry: ActivityEntry = {
      id: crypto.randomUUID(),
      date: selectedDate,
      activityName: actName.trim(),
      kms: km,
      caloriesBurned: burned,
    };
    setState({ ...state, activityLog: [...state.activityLog, entry] });
    setActName("");
    setKms("");
  }

  function deleteActivityLog(id: string) {
    setState({ ...state, activityLog: state.activityLog.filter((e) => e.id !== id) });
  }

  function saveCustomActivity() {
    if (!customName.trim() || !customCal.trim()) return;
    const cal = parseFloat(customCal);
    if (isNaN(cal) || cal <= 0) return;
    const act: CustomActivity = {
      id: crypto.randomUUID(),
      name: customName.trim(),
      calPerKm: cal,
    };
    setState({ ...state, customActivities: [...state.customActivities, act] });
    setCustomName("");
    setCustomCal("");
  }

  function deleteCustomActivity(id: string) {
    setState({ ...state, customActivities: state.customActivities.filter((a) => a.id !== id) });
  }

  function hideBuiltin(name: string) {
    setState({ ...state, hiddenBuiltins: [...state.hiddenBuiltins, name] });
  }

  function restoreBuiltins() {
    setState({ ...state, hiddenBuiltins: [] });
  }

  return (
    <div className="tab-content">
      <div className="card">
        <h2 className="section-title">Log Activity</h2>
        <div className="form-group" style={{ marginBottom: 10 }}>
          <label className="form-label">Date</label>
          <input
            className="form-input"
            type="date"
            value={logDate}
            max={toInputDate(todayStr())}
            onChange={(e) => setLogDate(e.target.value)}
          />
        </div>
        <div className="form-row">
          <div className="form-col-wide">
            <label className="form-label">Activity</label>
            <input
              className="form-input"
              list="activity-suggestions"
              placeholder="e.g. Running"
              value={actName}
              onChange={(e) => setActName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addActivity()}
            />
            <datalist id="activity-suggestions">
              {allActivities.map((a, i) => (
                <option key={i} value={a.name} />
              ))}
            </datalist>
          </div>
          <div className="form-col-narrow">
            <label className="form-label">Kms</label>
            <input
              className="form-input"
              type="number"
              min="0.1"
              step="0.1"
              placeholder="1"
              value={kms}
              onChange={(e) => setKms(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addActivity()}
            />
          </div>
          <button className="add-btn" onClick={addActivity}>+</button>
        </div>
      </div>

      {todayActivities.length > 0 && (
        <div className="card">
          <h2 className="section-title">Today's Activities</h2>
          <div className="food-list">
            {todayActivities.map((entry) => (
              <div key={entry.id} className="food-item">
                <div className="food-item-info">
                  <span className="food-item-name">{entry.activityName}</span>
                  <span className="food-item-meta">{entry.kms} km · {entry.caloriesBurned} cal burned</span>
                </div>
                <button className="delete-btn" onClick={() => deleteActivityLog(entry.id)}>🗑</button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="card">
        <h2 className="section-title">Add Custom Activity</h2>
        <p className="target-label">Add any activity with its cal/km burn rate</p>
        <div className="form-group">
          <label className="form-label">Activity Name</label>
          <input
            className="form-input"
            placeholder="e.g. Kabaddi"
            value={customName}
            onChange={(e) => setCustomName(e.target.value)}
          />
        </div>
        <div className="form-group" style={{ marginTop: 10 }}>
          <label className="form-label">Cal / km</label>
          <input
            className="form-input"
            type="number"
            placeholder="e.g. 50"
            value={customCal}
            onChange={(e) => setCustomCal(e.target.value)}
          />
        </div>
        <button className="save-btn" onClick={saveCustomActivity} style={{ marginTop: 12 }}>
          Save Activity
        </button>

        {state.customActivities.length > 0 && (
          <div style={{ marginTop: 16 }}>
            <h3 className="subsection-title">MY CUSTOM ({state.customActivities.length})</h3>
            <div className="food-list">
              {state.customActivities.map((a) => (
                <div key={a.id} className="food-item">
                  <div className="food-item-info">
                    <span className="food-item-name">{a.name}</span>
                    <span className="food-item-meta">{a.calPerKm} cal/km</span>
                  </div>
                  <button className="delete-btn" onClick={() => deleteCustomActivity(a.id)}>🗑</button>
                </div>
              ))}
            </div>
          </div>
        )}

        <div style={{ marginTop: 16 }}>
          <div className="subsection-header">
            <h3 className="subsection-title">
              BUILT-IN ({visibleBuiltins.length})
            </h3>
            {state.hiddenBuiltins.length > 0 && (
              <button className="restore-btn" onClick={restoreBuiltins}>
                Restore all
              </button>
            )}
          </div>
          <div className="food-list">
            {visibleBuiltins.map((a) => (
              <div key={a.name} className="food-item">
                <div className="food-item-info">
                  <span className="food-item-name">{a.name}</span>
                  <span className="food-item-meta">{a.calPerKm} cal/km</span>
                </div>
                <button className="delete-btn" onClick={() => hideBuiltin(a.name)}>🗑</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
