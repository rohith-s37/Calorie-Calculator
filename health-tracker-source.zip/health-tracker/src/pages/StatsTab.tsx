import { useMemo, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ReferenceLine, ResponsiveContainer, CartesianGrid } from "recharts";
import type { AppState } from "../types";
import { formatDate, exportData } from "../lib/storage";

interface Props {
  state: AppState;
}

function getDaysSummary(state: AppState) {
  const map = new Map<string, { eaten: number; burned: number }>();
  for (const e of state.foodLog) {
    const d = map.get(e.date) ?? { eaten: 0, burned: 0 };
    d.eaten += e.calories;
    map.set(e.date, d);
  }
  for (const e of state.activityLog) {
    const d = map.get(e.date) ?? { eaten: 0, burned: 0 };
    d.burned += e.caloriesBurned;
    map.set(e.date, d);
  }
  return map;
}

export default function StatsTab({ state }: Props) {
  const [range, setRange] = useState<7 | 30>(7);
  const CALORIE_TARGET = state.settings.calorieTarget;

  const summary = useMemo(() => getDaysSummary(state), [state]);

  const today = new Date();
  const chartData = useMemo(() => {
    const days: { label: string; net: number | null }[] = [];
    for (let i = range - 1; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const key = formatDate(d);
      const dayData = summary.get(key);
      const net = dayData ? dayData.eaten - dayData.burned : null;
      const label = `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}`;
      days.push({ label, net });
    }
    return days;
  }, [summary, range]);

  const daysTracked = summary.size;
  const onTarget = Array.from(summary.entries()).filter(([, v]) => {
    const net = v.eaten - v.burned;
    return net <= CALORIE_TARGET;
  }).length;

  const todayKey = formatDate(today);
  const streak = useMemo(() => {
    let count = 0;
    for (let i = 0; i <= 365; i++) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const key = formatDate(d);
      if (summary.has(key)) count++;
      else break;
    }
    return count;
  }, [summary]);

  const bestStreak = useMemo(() => {
    const sorted = Array.from(summary.keys()).sort();
    let best = 0;
    let cur = 0;
    let prev: Date | null = null;
    for (const key of sorted) {
      const [dd, mm, yyyy] = key.split("-").map(Number);
      const d = new Date(yyyy, mm - 1, dd);
      if (prev) {
        const diff = (d.getTime() - prev.getTime()) / 86400000;
        if (diff === 1) {
          cur++;
        } else {
          best = Math.max(best, cur);
          cur = 1;
        }
      } else {
        cur = 1;
      }
      prev = d;
    }
    return Math.max(best, cur);
  }, [summary]);

  const hasData = chartData.some((d) => d.net !== null);

  return (
    <div className="tab-content">
      <div className="card">
        <div className="streak-row">
          <div className="streak-left">
            <span className="streak-num">{streak}</span>
            <div>
              <div className="streak-title">day streak</div>
              <div className="streak-sub">Log today to start a streak</div>
            </div>
          </div>
          <div className="streak-right">
            <div className="streak-title">BEST</div>
            <div className="streak-best">{bestStreak}</div>
          </div>
        </div>
      </div>

      <div className="stats-twin-grid">
        <div className="stat-twin-box">
          <div className="stat-twin-label">DAYS TRACKED</div>
          <div className="stat-twin-num">{daysTracked}</div>
        </div>
        <div className="stat-twin-box">
          <div className="stat-twin-label">ON TARGET</div>
          <div className="stat-twin-num">{onTarget}</div>
        </div>
      </div>

      <div className="card">
        <div className="chart-header">
          <div>
            <h2 className="section-title" style={{ marginBottom: 2 }}>Calorie Trend</h2>
            <p className="target-label">Net calories vs {CALORIE_TARGET} kcal target</p>
          </div>
          <div className="range-btns">
            <button className={`range-btn ${range === 7 ? "active" : ""}`} onClick={() => setRange(7)}>7d</button>
            <button className={`range-btn ${range === 30 ? "active" : ""}`} onClick={() => setRange(30)}>30d</button>
          </div>
        </div>

        {!hasData ? (
          <div className="no-data-msg">No data yet — start logging food to see your trend.</div>
        ) : (
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={chartData} margin={{ top: 10, right: 10, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis dataKey="label" tick={{ fill: "#6b7fa3", fontSize: 10 }} tickLine={false} />
              <YAxis tick={{ fill: "#6b7fa3", fontSize: 10 }} tickLine={false} axisLine={false} />
              <Tooltip
                contentStyle={{ background: "#1a2540", border: "1px solid #2a3a5c", borderRadius: 8, color: "#fff" }}
                itemStyle={{ color: "#60a5fa" }}
              />
              <ReferenceLine y={CALORIE_TARGET} stroke="#6b7fa3" strokeDasharray="5 5" />
              <Line
                type="monotone"
                dataKey="net"
                stroke="#3b82f6"
                strokeWidth={2}
                dot={(props) => {
                  const { cx, cy, payload } = props;
                  if (payload.net === null) return <g key={`dot-${cx}-${cy}`} />;
                  const color = payload.net <= CALORIE_TARGET ? "#22c55e" : "#ef4444";
                  return <circle key={`dot-${cx}-${cy}`} cx={cx} cy={cy} r={4} fill={color} stroke="none" />;
                }}
                connectNulls={false}
              />
            </LineChart>
          </ResponsiveContainer>
        )}

        <div className="chart-legend">
          <span><span className="legend-dot green-dot" />On target</span>
          <span><span className="legend-dot red-dot" />Over limit</span>
          <span><span className="legend-dash" />{CALORIE_TARGET} kcal</span>
        </div>
      </div>

      <div className="card">
        <h2 className="section-title">Data Management</h2>
        <p className="target-label">Your data lives only on this device.</p>
        <button className="export-btn" onClick={() => exportData(state)}>
          ↓ Export All Data
        </button>
      </div>
    </div>
  );
}
