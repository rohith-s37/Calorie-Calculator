import { useState } from "react";
import type { AppState, FoodEntry, Meal } from "../types";
import { todayStr } from "../lib/storage";

interface Props {
  state: AppState;
  setState: (s: AppState) => void;
}

function toInputDate(ddmmyyyy: string): string {
  const [dd, mm, yyyy] = ddmmyyyy.split("-");
  return `${yyyy}-${mm}-${dd}`;
}

function fromInputDate(yyyymmdd: string): string {
  const [yyyy, mm, dd] = yyyymmdd.split("-");
  return `${dd}-${mm}-${yyyy}`;
}

const MEALS: { id: Meal; icon: string }[] = [
  { id: "Breakfast", icon: "🌅" },
  { id: "Lunch", icon: "☀️" },
  { id: "Snacks", icon: "🍎" },
  { id: "Dinner", icon: "🌙" },
];

export default function FoodTab({ state, setState }: Props) {
  const [foodName, setFoodName] = useState("");
  const [servings, setServings] = useState("1");
  const [meal, setMeal] = useState<Meal>("Breakfast");
  const [logDate, setLogDate] = useState(toInputDate(todayStr()));

  const { calorieTarget, proteinGoal, fiberGoal } = state.settings;
  const today = todayStr();
  const selectedDate = fromInputDate(logDate);
  const dayFood = state.foodLog.filter((e) => e.date === selectedDate);

  const eaten = dayFood.reduce((s, e) => s + e.calories, 0);
  const burned = state.activityLog.filter((e) => e.date === selectedDate).reduce((s, e) => s + e.caloriesBurned, 0);
  const net = eaten - burned;
  const remaining = calorieTarget - net;
  const protein = dayFood.reduce((s, e) => s + e.protein, 0);
  const fiber = dayFood.reduce((s, e) => s + e.fiber, 0);

  const proteinPct = Math.min((protein / proteinGoal) * 100, 100);
  const fiberPct = Math.min((fiber / fiberGoal) * 100, 100);

  const allFoods = state.customFoods;

  function addFood() {
    const srv = parseFloat(servings) || 1;
    if (!foodName.trim()) return;
    const match = allFoods.find((f) => f.name.toLowerCase() === foodName.trim().toLowerCase());
    const cal = match ? Math.round(match.calories * srv) : 0;
    const prot = match ? Math.round(match.protein * srv * 10) / 10 : 0;
    const fib = match ? Math.round(match.fiber * srv * 10) / 10 : 0;
    const entry: FoodEntry = {
      id: crypto.randomUUID(),
      date: selectedDate,
      meal,
      foodName: foodName.trim(),
      servings: srv,
      calories: cal,
      protein: prot,
      fiber: fib,
    };
    setState({ ...state, foodLog: [...state.foodLog, entry] });
    setFoodName("");
    setServings("1");
  }

  function deleteEntry(id: string) {
    setState({ ...state, foodLog: state.foodLog.filter((e) => e.id !== id) });
  }

  return (
    <div className="tab-content">
      <div className="card">
        <h2 className="section-title">Daily Summary</h2>
        <p className="target-label">Target: {calorieTarget} kcal</p>
        <div className="net-row">
          <span className="net-label">Net Calories</span>
          <span className="net-value">{net} / {calorieTarget}</span>
        </div>
        <div className="stats-grid">
          <div className="stat-box">
            <span className="stat-label">EATEN</span>
            <span className="stat-num">{eaten}</span>
          </div>
          <div className="stat-box">
            <span className="stat-label">BURNED</span>
            <span className="stat-num green">{burned}</span>
          </div>
          <div className="stat-box">
            <span className="stat-label">REMAINING</span>
            <span className="stat-num">{remaining}</span>
          </div>
        </div>
        <div className="macro-row">
          <span className="macro-label">Protein (Goal: {proteinGoal}g)</span>
          <div className="macro-bar-wrap">
            <div className="macro-bar">
              <div className="macro-bar-fill" style={{ width: `${proteinPct}%` }} />
            </div>
          </div>
          <span className="macro-val">{protein}g</span>
        </div>
        <div className="macro-row">
          <span className="macro-label">Fiber (Goal: {fiberGoal}g)</span>
          <div className="macro-bar-wrap">
            <div className="macro-bar">
              <div className="macro-bar-fill" style={{ width: `${fiberPct}%` }} />
            </div>
          </div>
          <span className="macro-val">{fiber}g</span>
        </div>
      </div>

      <div className="card">
        <h2 className="section-title">Add Food</h2>
        <div className="form-group" style={{ marginBottom: 10 }}>
          <label className="form-label">Date</label>
          <input
            className="form-input"
            type="date"
            value={logDate}
            max={toInputDate(todayStr())}
            onChange={(e) => setLogDate(e.target.value)}
          />
        </div>
        <div className="meal-selector">
          {MEALS.map((m) => (
            <button
              key={m.id}
              className={`meal-btn ${meal === m.id ? "active" : ""}`}
              onClick={() => setMeal(m.id)}
            >
              {m.icon} {m.id}
            </button>
          ))}
        </div>
        <div className="form-row" style={{ marginTop: 10 }}>
          <div className="form-col-wide">
            <label className="form-label">Food</label>
            <input
              className="form-input"
              list="food-suggestions"
              placeholder="e.g. Banana"
              value={foodName}
              onChange={(e) => setFoodName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addFood()}
            />
            <datalist id="food-suggestions">
              {allFoods.map((f) => (
                <option key={f.id} value={f.name} />
              ))}
            </datalist>
          </div>
          <div className="form-col-narrow">
            <label className="form-label">Servings</label>
            <input
              className="form-input"
              type="number"
              min="0.5"
              step="0.5"
              value={servings}
              onChange={(e) => setServings(e.target.value)}
            />
          </div>
          <button className="add-btn" onClick={addFood}>+</button>
        </div>
      </div>

      {dayFood.length > 0 && (
        <div className="card">
          <h2 className="section-title">{selectedDate === today ? "Today's Food" : `Food on ${selectedDate}`}</h2>
          {MEALS.map((m) => {
            const entries = dayFood.filter((e) => (e.meal ?? "Breakfast") === m.id);
            if (entries.length === 0) return null;
            const mealCal = entries.reduce((s, e) => s + e.calories, 0);
            return (
              <div key={m.id} className="meal-section">
                <div className="meal-section-header">
                  <span className="meal-section-title">{m.icon} {m.id}</span>
                  <span className="meal-section-cal">{mealCal} kcal</span>
                </div>
                <div className="food-list">
                  {entries.map((entry) => (
                    <div key={entry.id} className="food-item">
                      <div className="food-item-info">
                        <span className="food-item-name">{entry.foodName}</span>
                        <span className="food-item-meta">
                          {entry.servings} serving{entry.servings !== 1 ? "s" : ""} · {entry.calories} kcal
                          {entry.protein > 0 ? ` · P: ${entry.protein}g` : ""}
                          {entry.fiber > 0 ? ` · F: ${entry.fiber}g` : ""}
                        </span>
                      </div>
                      <button className="delete-btn" onClick={() => deleteEntry(entry.id)}>🗑</button>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
