import { useState } from "react";
import type { AppState, CustomFood } from "../types";

interface Props {
  state: AppState;
  setState: (s: AppState) => void;
}

export default function MyFoodsTab({ state, setState }: Props) {
  const [name, setName] = useState("");
  const [calories, setCalories] = useState("");
  const [protein, setProtein] = useState("");
  const [fiber, setFiber] = useState("");

  function saveFood() {
    if (!name.trim() || !calories.trim()) return;
    const food: CustomFood = {
      id: crypto.randomUUID(),
      name: name.trim(),
      calories: parseFloat(calories) || 0,
      protein: parseFloat(protein) || 0,
      fiber: parseFloat(fiber) || 0,
    };
    setState({ ...state, customFoods: [...state.customFoods, food] });
    setName("");
    setCalories("");
    setProtein("");
    setFiber("");
  }

  function deleteFood(id: string) {
    setState({ ...state, customFoods: state.customFoods.filter((f) => f.id !== id) });
  }

  return (
    <div className="tab-content">
      <div className="card">
        <h2 className="section-title">Add Custom Food</h2>
        <p className="target-label">Add frequently eaten foods to the database</p>
        <div className="form-group">
          <label className="form-label">Food Name</label>
          <input
            className="form-input"
            placeholder="e.g. My Protein Shake"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div className="form-row-3" style={{ marginTop: 12 }}>
          <div>
            <label className="form-label">Calories</label>
            <input
              className="form-input"
              type="number"
              min="0"
              value={calories}
              onChange={(e) => setCalories(e.target.value)}
            />
          </div>
          <div>
            <label className="form-label">Protein (g)</label>
            <input
              className="form-input"
              type="number"
              min="0"
              step="0.1"
              value={protein}
              onChange={(e) => setProtein(e.target.value)}
            />
          </div>
          <div>
            <label className="form-label">Fiber (g)</label>
            <input
              className="form-input"
              type="number"
              min="0"
              step="0.1"
              value={fiber}
              onChange={(e) => setFiber(e.target.value)}
            />
          </div>
        </div>
        <button className="save-btn" onClick={saveFood} style={{ marginTop: 12 }}>
          Save Food
        </button>
      </div>

      <div className="card">
        <div className="foods-grid">
          {state.customFoods.map((food) => (
            <div key={food.id} className="myfood-item">
              <div className="myfood-info">
                <div className="myfood-name">{food.name}</div>
                <div className="myfood-meta">{food.calories} kcal</div>
                <div className="myfood-macros">P: {food.protein}g | F: {food.fiber}g</div>
              </div>
              <button className="delete-btn" onClick={() => deleteFood(food.id)}>🗑</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
