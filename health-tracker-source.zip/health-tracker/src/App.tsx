import { useState, useEffect, useRef, useMemo } from "react";
import { AnimatePresence, motion } from "framer-motion";
import type { Tab } from "./types";
import { loadState, saveState, formatDate } from "./lib/storage";
import FoodTab from "./pages/FoodTab";
import ActivityTab from "./pages/ActivityTab";
import MyFoodsTab from "./pages/MyFoodsTab";
import StatsTab from "./pages/StatsTab";

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "food", label: "Food", icon: "🍽" },
  { id: "activity", label: "Activity", icon: "⚡" },
  { id: "myfoods", label: "My Foods", icon: "📋" },
  { id: "stats", label: "Stats", icon: "📊" },
];

const TAB_ORDER: Tab[] = ["food", "activity", "myfoods", "stats"];

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("food");
  const [direction, setDirection] = useState(1);
  const [state, setStateRaw] = useState(loadState);
  const [showSettings, setShowSettings] = useState(false);
  const [calInput, setCalInput] = useState("");
  const [protInput, setProtInput] = useState("");
  const [fibInput, setFibInput] = useState("");
  const prevTabRef = useRef<Tab>("food");

  useEffect(() => {
    saveState(state);
  }, [state]);

  function setState(s: typeof state) {
    setStateRaw(s);
  }

  function openSettings() {
    setCalInput(String(state.settings.calorieTarget));
    setProtInput(String(state.settings.proteinGoal));
    setFibInput(String(state.settings.fiberGoal));
    setShowSettings(true);
  }

  function saveSettings() {
    const cal = parseFloat(calInput);
    const prot = parseFloat(protInput);
    const fib = parseFloat(fibInput);
    if (!cal || cal <= 0) return;
    setState({
      ...state,
      settings: {
        calorieTarget: Math.round(cal),
        proteinGoal: prot > 0 ? Math.round(prot) : state.settings.proteinGoal,
        fiberGoal: fib > 0 ? Math.round(fib) : state.settings.fiberGoal,
      },
    });
    setShowSettings(false);
  }

  function switchTab(tab: Tab) {
    const curIdx = TAB_ORDER.indexOf(activeTab);
    const newIdx = TAB_ORDER.indexOf(tab);
    setDirection(newIdx >= curIdx ? 1 : -1);
    prevTabRef.current = activeTab;
    setActiveTab(tab);
  }

  const today = new Date();
  const dateStr = formatDate(today);

  const streak = useMemo(() => {
    const loggedDays = new Set(state.foodLog.map((e) => e.date));
    let count = 0;
    for (let i = 0; i <= 365; i++) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      if (loggedDays.has(formatDate(d))) count++;
      else break;
    }
    return count;
  }, [state.foodLog]);

  const variants = {
    enter: (dir: number) => ({ x: dir > 0 ? "100%" : "-100%", opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (dir: number) => ({ x: dir > 0 ? "-100%" : "100%", opacity: 0 }),
  };

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-brand">
          <span className="brand-icon">⚡</span>
          <span className="brand-name">Health Tracker Pro</span>
        </div>
        <div className="header-right">
          <div className="header-date">{dateStr}</div>
          <button className="settings-btn" onClick={openSettings} title="Settings">⚙</button>
        </div>
      </header>

      <nav className="tab-nav">
        <div className="tab-nav-inner">
          {TABS.map((t) => (
            <button
              key={t.id}
              className={`tab-btn ${activeTab === t.id ? "active" : ""}`}
              onClick={() => switchTab(t.id)}
            >
              <span className="tab-icon">{t.icon}</span>
              <span className="tab-label">{t.label}</span>
            </button>
          ))}
        </div>
      </nav>

      <div className="page-wrap">
        <AnimatePresence initial={false} custom={direction} mode="wait">
          <motion.div
            key={activeTab}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ type: "tween", duration: 0.22, ease: "easeInOut" }}
            className="page-inner"
          >
            {activeTab === "food" && <FoodTab state={state} setState={setState} />}
            {activeTab === "activity" && <ActivityTab state={state} setState={setState} />}
            {activeTab === "myfoods" && <MyFoodsTab state={state} setState={setState} />}
            {activeTab === "stats" && <StatsTab state={state} />}
          </motion.div>
        </AnimatePresence>
      </div>

      {showSettings && (
        <div className="modal-overlay" onClick={() => setShowSettings(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2 className="section-title">Goals & Settings</h2>
              <button className="modal-close" onClick={() => setShowSettings(false)}>✕</button>
            </div>

            <div className="modal-body">
              <div className="form-group">
                <label className="form-label">Daily Calorie Target (kcal)</label>
                <input
                  className="form-input"
                  type="number"
                  min="500"
                  max="10000"
                  value={calInput}
                  onChange={(e) => setCalInput(e.target.value)}
                />
              </div>
              <div className="form-group" style={{ marginTop: 14 }}>
                <label className="form-label">Protein Goal (g)</label>
                <input
                  className="form-input"
                  type="number"
                  min="0"
                  value={protInput}
                  onChange={(e) => setProtInput(e.target.value)}
                />
              </div>
              <div className="form-group" style={{ marginTop: 14 }}>
                <label className="form-label">Fiber Goal (g)</label>
                <input
                  className="form-input"
                  type="number"
                  min="0"
                  value={fibInput}
                  onChange={(e) => setFibInput(e.target.value)}
                />
              </div>

              <button className="save-btn" style={{ marginTop: 20 }} onClick={saveSettings}>
                Save Goals
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
