export type Tab = "food" | "activity" | "myfoods" | "stats";

export type Meal = "Breakfast" | "Lunch" | "Snacks" | "Dinner";

export interface FoodEntry {
  id: string;
  date: string;
  meal: Meal;
  foodName: string;
  servings: number;
  calories: number;
  protein: number;
  fiber: number;
}

export interface ActivityEntry {
  id: string;
  date: string;
  activityName: string;
  kms: number;
  caloriesBurned: number;
}

export interface CustomFood {
  id: string;
  name: string;
  calories: number;
  protein: number;
  fiber: number;
}

export interface CustomActivity {
  id: string;
  name: string;
  calPerKm: number;
}

export interface Settings {
  calorieTarget: number;
  proteinGoal: number;
  fiberGoal: number;
}

export interface AppState {
  foodLog: FoodEntry[];
  activityLog: ActivityEntry[];
  customFoods: CustomFood[];
  customActivities: CustomActivity[];
  hiddenBuiltins: string[];
  settings: Settings;
}
